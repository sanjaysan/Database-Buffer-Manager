var searchData=
[
  ['recordid',['RecordId',['../structbadgerdb_1_1_record_id.html',1,'badgerdb']]]
];
