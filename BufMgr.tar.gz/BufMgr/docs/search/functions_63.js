var searchData=
[
  ['clear',['clear',['../structbadgerdb_1_1_buf_stats.html#a04a848e5458491fd3ea56133464cadbd',1,'badgerdb::BufStats']]],
  ['clearbufstats',['clearBufStats',['../classbadgerdb_1_1_buf_mgr.html#a702a264ae946b334414e51700edd81a0',1,'badgerdb::BufMgr']]],
  ['create',['create',['../classbadgerdb_1_1_file.html#a1fb708b45103a606f189850d6bf83a0c',1,'badgerdb::File']]]
];
